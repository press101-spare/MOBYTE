import { NOTICE_PATTERNS, STEAM_NEWS_API } from './constants.js';

function decodeEntities(text = '') {
  return text.replace(/&lt;/g, '<').replace(/&gt;/g, '>').replace(/&amp;/g, '&')
    .replace(/&quot;/g, '"').replace(/&#039;/g, "'");
}

function plainText(html = '') {
  return decodeEntities(html)
    .replace(/\[img\].*?\[\/img\]/gis, '')
    .replace(/\[url=.*?\](.*?)\[\/url\]/gis, '$1')
    .replace(/\[[^\]]+\]/g, ' ')
    .replace(/<[^>]+>/g, ' ')
    .replace(/\s+/g, ' ').trim();
}

function firstImage(contents = '') {
  return contents.match(/\[img\](https?:\/\/[^\[]+)\[\/img\]/i)?.[1]
    ?? contents.match(/<img[^>]+src=["'](https?:\/\/[^"']+)/i)?.[1]
    ?? null;
}

export function classifyNotice(title) {
  if (NOTICE_PATTERNS.identity.test(title)) return 'identity';
  if (NOTICE_PATTERNS.ego.test(title)) return 'ego';
  if (NOTICE_PATTERNS.major.test(title)) return 'major';
  return null;
}

export async function fetchLimbusNews() {
  const response = await fetch(STEAM_NEWS_API, { signal: AbortSignal.timeout(15000) });
  if (!response.ok) throw new Error(`Steam News HTTP ${response.status}`);
  const json = await response.json();
  return (json?.appnews?.newsitems ?? []).map(item => ({
    id: String(item.gid), title: item.title, url: item.url,
    date: new Date(item.date * 1000), category: classifyNotice(item.title),
    summary: plainText(item.contents).slice(0, 900), image: firstImage(item.contents)
  }));
}
