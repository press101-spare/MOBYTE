import 'dotenv/config';
import { ChannelType, REST, Routes, SlashCommandBuilder } from 'discord.js';

if (!process.env.DISCORD_TOKEN || !process.env.CLIENT_ID) throw new Error('DISCORD_TOKEN과 CLIENT_ID를 .env에 입력하세요.');

const commands = [
  new SlashCommandBuilder().setName('림버스설정').setDescription('신규 소식을 받을 채널을 설정합니다.')
    .setDefaultMemberPermissions('32').addChannelOption(o => o.setName('채널').setDescription('알림 채널').addChannelTypes(ChannelType.GuildText).setRequired(true)),
  new SlashCommandBuilder().setName('인격').setDescription('인격을 검색하고 효과를 조회합니다.')
    .addStringOption(o => o.setName('검색어').setDescription('인격명, 수감자, 키워드').setRequired(true)),
  new SlashCommandBuilder().setName('ego').setDescription('E.G.O를 검색하고 효과를 조회합니다.')
    .addStringOption(o => o.setName('검색어').setDescription('E.G.O명, 수감자, 키워드').setRequired(true)),
  new SlashCommandBuilder().setName('키워드').setDescription('상태 효과 또는 키워드를 검색합니다.')
    .addStringOption(o => o.setName('이름').setDescription('예: 출혈, 파열, Bleed').setRequired(true)),
  new SlashCommandBuilder().setName('최근소식').setDescription('최근 공식 림버스 소식을 확인합니다.')
    .addIntegerOption(o => o.setName('개수').setDescription('1~10개').setMinValue(1).setMaxValue(10)),
  new SlashCommandBuilder().setName('동기화').setDescription('공식 공지를 지금 확인합니다.').setDefaultMemberPermissions('32')
].map(c => c.toJSON());

const rest = new REST({ version: '10' }).setToken(process.env.DISCORD_TOKEN);
const route = process.env.GUILD_ID ? Routes.applicationGuildCommands(process.env.CLIENT_ID, process.env.GUILD_ID) : Routes.applicationCommands(process.env.CLIENT_ID);
await rest.put(route, { body: commands });
console.log(`${commands.length}개 명령어 등록 완료 (${process.env.GUILD_ID ? '테스트 서버' : '전체 서버'})`);
