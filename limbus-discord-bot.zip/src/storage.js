import fs from 'node:fs/promises';
import path from 'node:path';
import { fileURLToPath } from 'node:url';

const root = path.resolve(path.dirname(fileURLToPath(import.meta.url)), '..');
const dataDir = path.join(root, 'data');

async function readJson(name, fallback) {
  await fs.mkdir(dataDir, { recursive: true });
  try { return JSON.parse(await fs.readFile(path.join(dataDir, name), 'utf8')); }
  catch (error) {
    if (error.code !== 'ENOENT') console.error(`[storage] ${name}:`, error.message);
    return structuredClone(fallback);
  }
}

async function writeJson(name, value) {
  await fs.mkdir(dataDir, { recursive: true });
  const target = path.join(dataDir, name);
  const temp = `${target}.tmp`;
  await fs.writeFile(temp, JSON.stringify(value, null, 2), 'utf8');
  await fs.rename(temp, target);
}

export const storage = {
  getState: () => readJson('state.json', { seenNewsIds: [] }),
  setState: (value) => writeJson('state.json', value),
  getSettings: () => readJson('settings.json', { guilds: {} }),
  setSettings: (value) => writeJson('settings.json', value),
  getCache: () => readJson('cache.json', { pages: {} }),
  setCache: (value) => writeJson('cache.json', value)
};
