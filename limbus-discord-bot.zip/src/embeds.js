import { ActionRowBuilder, ButtonBuilder, ButtonStyle, EmbedBuilder } from 'discord.js';
import { createHash } from 'node:crypto';
import { COLORS } from './constants.js';

// Discord customId는 100자 제한이 있어 한글 문서명을 직접 넣지 않습니다.
// 봇 재시작 전까지 검색 결과 버튼과 위키 문서명을 연결합니다.
export const buttonPageTitles = new Map();

export function noticeEmbed(item) {
  const names = { identity: '신규 인격', ego: '신규 E.G.O', major: '주요 업데이트' };
  const embed = new EmbedBuilder().setColor(item.category === 'ego' ? COLORS.gold : COLORS.red)
    .setTitle(`[${names[item.category]}] ${item.title}`).setURL(item.url)
    .setDescription(item.summary || '공식 공지에서 상세 내용을 확인해 주세요.')
    .setTimestamp(item.date).setFooter({ text: '출처: Project Moon 공식 Steam 공지' });
  if (item.image) embed.setImage(item.image);
  return embed;
}

export function searchEmbed(results, query, type) {
  return new EmbedBuilder().setColor(COLORS.gray)
    .setTitle(`${type === 'ego' ? 'E.G.O' : '인격'} 검색: ${query}`)
    .setDescription(results.length ? results.map((r, i) => `**${i + 1}. ${r.title}**\n${r.snippet || '설명 없음'}`).join('\n\n').slice(0, 4000) : '검색 결과가 없습니다.')
    .setFooter({ text: '상세 데이터 출처: Limbus Company Wiki (커뮤니티 편집)' });
}

export function resultButtons(results, type) {
  if (!results.length) return [];
  return [new ActionRowBuilder().addComponents(...results.slice(0, 5).map((r, i) =>
    {
      const key = createHash('sha256').update(`${type}:${r.title}`).digest('hex').slice(0, 20);
      buttonPageTitles.set(key, r.title);
      return new ButtonBuilder().setCustomId(`wiki:${type}:${key}`).setLabel(`${i + 1}. 상세 보기`).setStyle(ButtonStyle.Secondary);
    }
  ))];
}

export function detailEmbed(page) {
  const candidates = [...page.sections, ...page.fields].filter(x => x.name && x.value).slice(0, 12);
  const embed = new EmbedBuilder().setColor(COLORS.red).setTitle(page.title).setURL(page.url)
    .setDescription(page.intro || '위키 문서의 상세 정보를 표시합니다.')
    .setFooter({ text: '커뮤니티 위키 정보 · 정확한 최신 수치는 게임 내 표기를 우선하세요.' });
  if (page.image) embed.setThumbnail(page.image);
  // 임베드 전체 6000자 제한을 넘지 않도록 상세 항목을 예산 안에서 자릅니다.
  let remaining = Math.max(0, 5000 - page.title.length - (page.intro?.length ?? 0));
  const fields = [];
  for (const item of candidates) {
    if (remaining < 100) break;
    const name = item.name.slice(0, Math.min(256, remaining));
    remaining -= name.length;
    const value = item.value.slice(0, Math.min(1024, remaining));
    remaining -= value.length;
    if (name && value) fields.push({ name, value, inline: false });
  }
  if (fields.length) embed.addFields(fields);
  return embed;
}
