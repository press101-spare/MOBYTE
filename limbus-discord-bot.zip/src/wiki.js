import * as cheerio from 'cheerio';
import { WIKI_API } from './constants.js';
import { storage } from './storage.js';

function apiUrl(params) {
  const url = new URL(WIKI_API);
  for (const [key, value] of Object.entries({ origin: '*', format: 'json', formatversion: '2', ...params })) url.searchParams.set(key, value);
  return url;
}

async function wikiRequest(params) {
  const response = await fetch(apiUrl(params), { headers: { 'User-Agent': 'LimbusArchiveDiscordBot/1.0' }, signal: AbortSignal.timeout(15000) });
  if (!response.ok) throw new Error(`Wiki HTTP ${response.status}`);
  return response.json();
}

export async function searchWiki(query, type = 'identity', limit = 10) {
  const suffix = type === 'ego' ? ' E.G.O' : ' Identity';
  const json = await wikiRequest({ action: 'query', list: 'search', srsearch: `${query}${suffix}`, srlimit: String(limit), srnamespace: '0' });
  return (json?.query?.search ?? []).map(row => ({ title: row.title, snippet: cheerio.load(row.snippet).text() }));
}

function normalize(text) { return text.replace(/\[[^\]]*edit[^\]]*\]/gi, '').replace(/\s+/g, ' ').trim(); }

function extractPage(title, html) {
  const $ = cheerio.load(html);
  $('script, style, .mw-editsection, sup.reference, .navbox, .toc').remove();
  const image = $('.infobox img, .character-infobox img, figure img').first().attr('src');
  const fields = [];
  $('.infobox tr, table.wikitable tr').each((_, row) => {
    const cells = $(row).find('th,td').map((__, cell) => normalize($(cell).text())).get().filter(Boolean);
    if (cells.length >= 2 && fields.length < 24) fields.push({ name: cells[0].slice(0, 80), value: cells.slice(1).join(' · ').slice(0, 900) });
  });
  const sections = [];
  $('h2,h3').each((_, heading) => {
    const name = normalize($(heading).text());
    if (!/skill|passive|combat|effect|identity|ego|스킬|패시브|효과/i.test(name)) return;
    let text = '';
    let node = $(heading).next();
    while (node.length && !/^h[23]$/i.test(node[0]?.name ?? '')) { text += ` ${node.text()}`; node = node.next(); }
    text = normalize(text);
    if (text) sections.push({ name: name.slice(0, 80), value: text.slice(0, 1000) });
  });
  const intro = normalize($('#mw-content-text p').filter((_, p) => $(p).text().trim().length > 50).first().text()).slice(0, 900);
  return { title, url: `https://limbuscompany.wiki.gg/wiki/${encodeURIComponent(title.replace(/ /g, '_'))}`, image: image ? new URL(image, 'https://limbuscompany.wiki.gg').href : null, intro, fields, sections };
}

export async function getWikiPage(title) {
  const cache = await storage.getCache();
  const hit = cache.pages[title];
  if (hit && Date.now() - hit.savedAt < 6 * 60 * 60 * 1000) return hit.data;
  const json = await wikiRequest({ action: 'parse', page: title, prop: 'text' });
  if (json?.error) throw new Error(json.error.info);
  const data = extractPage(title, json.parse.text);
  cache.pages[title] = { savedAt: Date.now(), data };
  const keys = Object.keys(cache.pages);
  if (keys.length > 100) for (const key of keys.sort((a,b) => cache.pages[a].savedAt - cache.pages[b].savedAt).slice(0, keys.length - 100)) delete cache.pages[key];
  await storage.setCache(cache);
  return data;
}
