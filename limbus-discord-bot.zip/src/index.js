import 'dotenv/config';
import { Client, Events, GatewayIntentBits, PermissionFlagsBits } from 'discord.js';
import { buttonPageTitles, detailEmbed, noticeEmbed, resultButtons, searchEmbed } from './embeds.js';
import { fetchLimbusNews } from './steam-news.js';
import { storage } from './storage.js';
import { getWikiPage, searchWiki } from './wiki.js';

if (!process.env.DISCORD_TOKEN) throw new Error('DISCORD_TOKEN을 .env에 입력하세요.');
const client = new Client({ intents: [GatewayIntentBits.Guilds] });
let checking = false;

async function configuredChannels() {
  const settings = await storage.getSettings();
  const ids = new Set(Object.values(settings.guilds).map(x => x.channelId).filter(Boolean));
  if (process.env.DEFAULT_CHANNEL_ID) ids.add(process.env.DEFAULT_CHANNEL_ID);
  return [...ids];
}

async function checkNews({ announce = true, initialize = false } = {}) {
  if (checking) return [];
  checking = true;
  try {
    const [news, state] = await Promise.all([fetchLimbusNews(), storage.getState()]);
    const relevant = news.filter(x => x.category);
    const unseen = relevant.filter(x => !state.seenNewsIds.includes(x.id));
    if (initialize && state.seenNewsIds.length === 0) unseen.length = 0;
    if (announce && unseen.length) {
      for (const channelId of await configuredChannels()) {
        try {
          const channel = await client.channels.fetch(channelId);
          if (!channel?.isTextBased()) continue;
          for (const item of unseen.slice().reverse()) await channel.send({ embeds: [noticeEmbed(item)] });
        } catch (error) { console.error(`[channel ${channelId}]`, error.message); }
      }
    }
    state.seenNewsIds = [...new Set([...relevant.map(x => x.id), ...state.seenNewsIds])].slice(0, 500);
    await storage.setState(state);
    return unseen;
  } finally { checking = false; }
}

async function showSearch(interaction, query, type) {
  await interaction.deferReply();
  const results = await searchWiki(query, type, 5);
  await interaction.editReply({ embeds: [searchEmbed(results, query, type)], components: resultButtons(results, type) });
}

client.once(Events.ClientReady, async ready => {
  console.log(`${ready.user.tag} 로그인 완료`);
  await checkNews({ announce: false, initialize: true }).catch(console.error);
  const minutes = Math.max(5, Number(process.env.CHECK_INTERVAL_MINUTES) || 10);
  setInterval(() => checkNews().catch(console.error), minutes * 60 * 1000);
});

client.on(Events.InteractionCreate, async interaction => {
  try {
    if (interaction.isButton() && interaction.customId.startsWith('wiki:')) {
      await interaction.deferReply({ ephemeral: true });
      const [, , key] = interaction.customId.split(':');
      const title = buttonPageTitles.get(key);
      if (!title) return interaction.editReply('봇이 재시작되어 이 버튼의 검색 정보가 만료되었습니다. 명령어로 다시 검색해 주세요.');
      const page = await getWikiPage(title);
      return interaction.editReply({ embeds: [detailEmbed(page)] });
    }
    if (!interaction.isChatInputCommand()) return;
    if (interaction.commandName === '림버스설정') {
      if (!interaction.memberPermissions?.has(PermissionFlagsBits.ManageGuild)) return interaction.reply({ content: '서버 관리 권한이 필요합니다.', ephemeral: true });
      const channel = interaction.options.getChannel('채널', true);
      const settings = await storage.getSettings();
      settings.guilds[interaction.guildId] = { channelId: channel.id };
      await storage.setSettings(settings);
      return interaction.reply({ content: `앞으로 ${channel} 채널에 주요 소식을 알려드릴게요.`, ephemeral: true });
    }
    if (interaction.commandName === '인격') return showSearch(interaction, interaction.options.getString('검색어', true), 'identity');
    if (interaction.commandName === 'ego') return showSearch(interaction, interaction.options.getString('검색어', true), 'ego');
    if (interaction.commandName === '키워드') return showSearch(interaction, interaction.options.getString('이름', true), 'identity');
    if (interaction.commandName === '최근소식') {
      await interaction.deferReply();
      const count = interaction.options.getInteger('개수') ?? 5;
      const news = (await fetchLimbusNews()).filter(x => x.category).slice(0, count);
      return interaction.editReply({ embeds: news.map(noticeEmbed) });
    }
    if (interaction.commandName === '동기화') {
      await interaction.deferReply({ ephemeral: true });
      const unseen = await checkNews();
      return interaction.editReply(unseen.length ? `${unseen.length}개의 새 공지를 전송했습니다.` : '새로운 주요 공지가 없습니다.');
    }
  } catch (error) {
    console.error(error);
    const message = '처리 중 오류가 발생했습니다. 잠시 뒤 다시 시도해 주세요.';
    if (interaction.deferred || interaction.replied) await interaction.editReply({ content: message, embeds: [], components: [] }).catch(() => {});
    else await interaction.reply({ content: message, ephemeral: true }).catch(() => {});
  }
});

client.login(process.env.DISCORD_TOKEN);
