export const STEAM_APP_ID = '1973530';
export const STEAM_NEWS_API = `https://api.steampowered.com/ISteamNews/GetNewsForApp/v2/?appid=${STEAM_APP_ID}&count=50&maxlength=0&format=json`;
export const WIKI_API = 'https://limbuscompany.wiki.gg/api.php';
export const COLORS = { red: 0x9f1d2d, gold: 0xc8a45a, gray: 0x37373d };

export const NOTICE_PATTERNS = {
  identity: /new identity|신규\s*인격|identity preview|identity target extraction/i,
  ego: /new e\.?g\.?o|신규\s*e\.?g\.?o|e\.?g\.?o preview|e\.?g\.?o target extraction/i,
  major: /scheduled update|update notice|roadmap|developer livestream|new content|combat|system|시스템|로드맵|업데이트/i
};

export const KEYWORDS = [
  'Bleed', 'Burn', 'Rupture', 'Sinking', 'Tremor', 'Poise', 'Charge',
  '출혈', '화상', '파열', '침잠', '진동', '호흡', '충전'
];
