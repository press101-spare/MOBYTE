# 림버스 인격 도감 · 알림 디스코드 봇

Project Moon의 공식 Steam 공지를 주기적으로 확인해 신규 인격, 신규 E.G.O, 주요 업데이트를 지정 채널에 알립니다. `/인격`, `/ego`, `/키워드` 명령으로 커뮤니티 위키를 검색하고 버튼으로 스킬·패시브·효과 정보를 볼 수 있습니다.

## 주요 기능

- 신규 인격·E.G.O·주요 업데이트 자동 알림
- 공식 공지 이미지, 요약, 원문 링크 표시
- 인격/E.G.O 이름·수감자·키워드 검색
- 검색 결과 버튼식 상세 도감
- 서버별 알림 채널 설정
- 이미 보낸 공지 중복 방지
- 6시간 위키 캐시와 간단한 JSON 저장소

## 설치

1. [Discord Developer Portal](https://discord.com/developers/applications)에서 애플리케이션을 만들고 Bot을 추가합니다.
2. Bot 페이지에서 토큰을 발급합니다. 토큰은 누구에게도 보여주지 마세요.
3. OAuth2 → URL Generator에서 `bot`, `applications.commands`를 선택합니다.
4. 봇 권한은 `View Channels`, `Send Messages`, `Embed Links`, `Read Message History`를 선택해 서버에 초대합니다.
5. Node.js 20 이상이 설치된 터미널에서 다음을 실행합니다.

```bash
npm install
cp .env.example .env
```

Windows에서는 `.env.example`을 복사해 이름을 `.env`로 바꾸면 됩니다. `.env`에 `DISCORD_TOKEN`, `CLIENT_ID`, 테스트 서버의 `GUILD_ID`를 입력하세요.

```bash
npm run register
npm start
```

서버에서 `/림버스설정 채널:#알림채널`을 한 번 실행하면 설정이 끝납니다.

### Windows 간편 설치

1. 압축을 풀고 `설정하기.bat`을 더블클릭합니다.
2. 자동으로 열린 `.env` 메모장에 봇 토큰과 ID를 입력하고 저장합니다.
3. 명령어 등록이 끝나면 `실행하기.bat`을 더블클릭합니다.
4. 디스코드 서버에서 `/림버스설정`을 실행합니다.

봇 토큰을 재발급하거나 `.env`를 수정했다면 `설정하기.bat`을 다시 실행해 명령어를 등록할 수 있습니다.

## 명령어

| 명령어 | 설명 |
|---|---|
| `/림버스설정` | 관리자용 알림 채널 설정 |
| `/인격 검색어:` | 인격 검색 및 상세 효과 조회 |
| `/ego 검색어:` | E.G.O 검색 및 상세 효과 조회 |
| `/키워드 이름:` | 출혈·파열 등의 키워드 관련 문서 검색 |
| `/최근소식 개수:` | 최근 공식 주요 공지 보기 |
| `/동기화` | 관리자가 즉시 새 공지 확인 |

## 데이터 출처와 주의점

- 알림: Project Moon의 Limbus Company 공식 Steam News
- 상세 도감: Limbus Company Wiki(wiki.gg), 커뮤니티 편집 자료

봇은 각 화면에 출처를 표시합니다. 패치 직후 위키 수치가 늦게 갱신될 수 있으므로 최종 수치는 게임 내 설명을 우선하세요. 웹사이트 구조가 바뀌면 `src/wiki.js`의 추출 규칙을 수정해야 할 수 있습니다.

## 24시간 실행

개인 PC에서는 터미널을 닫으면 봇도 종료됩니다. 장기 운영은 Railway, Render, Fly.io 또는 VPS 같은 Node.js 호스팅에 올리세요. `.env` 파일과 봇 토큰은 GitHub에 올리지 마세요.
