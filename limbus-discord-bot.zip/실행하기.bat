@echo off
chcp 65001 > nul
title 림버스 인격 도감 봇
cd /d "%~dp0"

if not exist .env (
  echo 먼저 설정하기.bat을 실행해 주세요.
  pause
  exit /b 1
)

call npm start
echo.
echo 봇이 종료되었습니다. 위의 오류 내용을 확인하세요.
pause
