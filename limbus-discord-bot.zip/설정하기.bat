@echo off
chcp 65001 > nul
title 림버스 봇 설정
cd /d "%~dp0"

if not exist node_modules (
  echo [1/3] 필요한 파일을 설치합니다.
  call npm install
  if errorlevel 1 goto error
)

if not exist .env (
  copy .env.example .env > nul
  echo [2/3] .env 파일을 만들었습니다.
  echo 메모장에서 토큰과 ID를 입력한 뒤 저장해 주세요.
  notepad .env
) else (
  echo [2/3] 기존 .env 파일을 사용합니다.
)

echo [3/3] 디스코드 슬래시 명령어를 등록합니다.
call npm run register
if errorlevel 1 goto error

echo.
echo 설정 완료! 이제 실행하기.bat을 더블클릭하세요.
pause
exit /b 0

:error
echo.
echo 설정 중 오류가 발생했습니다. Node.js 20 이상과 .env 내용을 확인하세요.
pause
exit /b 1
